@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<h2>Mostrar Empleado</h2>

<p>ID: {{ $empleado->id }}</p>

<p>Nombre: {{ $empleado->nombre }}</p>

<p>Apellido: {{ $empleado->apellido }}</p>

<p>Puesto: {{ $empleado->puesto }}</p>

<p>Salario: {{ $empleado->salario }}</p>

<p>Sucursal ID: {{ $empleado->sucursal_id }}</p>

<p>Estado: {{ $empleado->estado }}</p>

@if($empleado->imagen)

<img
src="{{ asset('imagenes/'.$empleado->imagen) }}"
width="150">

@endif

<br><br>

<a href="{{ route('empleados.formulario') }}">
Volver
</a>

</div>

@endsection