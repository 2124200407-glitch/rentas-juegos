@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl shadow-lg">

    <h2 class="text-2xl font-bold text-cyan-400 mb-6 text-center">
        Editar Empleado
    </h2>

    <form method="POST"
          action="{{ route('empleados.actualizar',$empleado->id) }}"
          enctype="multipart/form-data">

        @csrf

        <input type="text"
               name="nombre"
               value="{{ $empleado->nombre }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <input type="text"
               name="apellido"
               value="{{ $empleado->apellido }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <input type="text"
               name="puesto"
               value="{{ $empleado->puesto }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <input type="number"
               step="0.01"
               name="salario"
               value="{{ $empleado->salario }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <input type="number"
               name="sucursal_id"
               value="{{ $empleado->sucursal_id }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <input type="file"
               name="imagen"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-2">

        <select name="estado"
                class="w-full p-3 rounded-lg bg-slate-700 text-white mb-4">

            <option value="Activo"
            {{ $empleado->estado == 'Activo' ? 'selected' : '' }}>
                Activo
            </option>

            <option value="Inactivo"
            {{ $empleado->estado == 'Inactivo' ? 'selected' : '' }}>
                Inactivo
            </option>

        </select>

        <button type="submit"
                class="w-full bg-green-500 py-3 rounded-lg font-bold">
            Actualizar
        </button>

    </form>

</div>

@endsection