@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<h2>Mostrar Proveedor</h2>

<p>ID: {{ $proveedor->id }}</p>

<p>Nombre: {{ $proveedor->nombre }}</p>

<p>Teléfono: {{ $proveedor->telefono }}</p>

<p>Correo: {{ $proveedor->correo }}</p>

<p>Estado: {{ $proveedor->estado }}</p>

@if($proveedor->imagen)

<img
src="{{ asset('imagenes/'.$proveedor->imagen) }}"
width="150">

@endif

<br><br>

<a href="{{ route('proveedores.formulario') }}">
Volver
</a>

</div>

@endsection