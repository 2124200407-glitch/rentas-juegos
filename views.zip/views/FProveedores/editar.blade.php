@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl shadow-lg">

    <h2 class="text-2xl font-bold text-cyan-400 mb-6 text-center">
        Editar Proveedor
    </h2>

    <form method="POST"
          action="{{ route('proveedores.actualizar',$proveedor->id) }}"
          enctype="multipart/form-data">

        @csrf

        <input type="text"
               name="nombre"
               value="{{ $proveedor->nombre }}"
               class="w-full p-3 mb-3 rounded-lg bg-slate-700 text-white">

        <input type="text"
               name="telefono"
               value="{{ $proveedor->telefono }}"
               class="w-full p-3 mb-3 rounded-lg bg-slate-700 text-white">

        <input type="email"
               name="correo"
               value="{{ $proveedor->correo }}"
               class="w-full p-3 mb-3 rounded-lg bg-slate-700 text-white">

        <input type="file"
               name="imagen"
               class="w-full p-3 mb-3 rounded-lg bg-slate-700 text-white">

        <select name="estado"
                class="w-full p-3 mb-3 rounded-lg bg-slate-700 text-white">

            <option value="Activo"
                {{ $proveedor->estado == 'Activo' ? 'selected' : '' }}>
                Activo
            </option>

            <option value="Inactivo"
                {{ $proveedor->estado == 'Inactivo' ? 'selected' : '' }}>
                Inactivo
            </option>

        </select>

        <button type="submit"
                class="w-full bg-yellow-500 py-3 rounded-lg font-bold">

            Actualizar

        </button>

    </form>

</div>

@endsection