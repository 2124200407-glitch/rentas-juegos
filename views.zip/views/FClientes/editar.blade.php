@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<form method="POST"
      action="{{ route('clientes.actualizar',$cliente->id) }}"
      enctype="multipart/form-data">

@csrf

<input type="text"
       name="nombre"
       value="{{ $cliente->nombre }}"
       class="w-full p-3 mb-3">

<input type="text"
       name="apellido"
       value="{{ $cliente->apellido }}"
       class="w-full p-3 mb-3">

<input type="text"
       name="telefono"
       value="{{ $cliente->telefono }}"
       class="w-full p-3 mb-3">

<input type="email"
       name="correo"
       value="{{ $cliente->correo }}"
       class="w-full p-3 mb-3">

<select name="estado" class="w-full p-3 mb-3">

    <option value="Activo"
        {{ $cliente->estado=='Activo' ? 'selected':'' }}>
        Activo
    </option>

    <option value="Inactivo"
        {{ $cliente->estado=='Inactivo' ? 'selected':'' }}>
        Inactivo
    </option>

</select>

<input type="file" name="imagen" class="w-full mb-3">

<button class="bg-cyan-500 p-3 rounded">
    Actualizar
</button>

</form>

</div>

@endsection