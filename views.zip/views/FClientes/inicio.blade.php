@extends('plantilla.base')
@extends('layouts.app')
@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl shadow-lg">

    <h2 class="text-2xl font-bold text-cyan-400 mb-6 text-center">
        Formulario Clientes
    </h2>

   <form method="POST"
      action="{{ route('clientes.guardar') }}"
      enctype="multipart/form-data">

    @csrf

    <input type="text"
           name="nombre"
           placeholder="Nombre">

    <input type="text"
           name="apellido"
           placeholder="Apellido">

    <input type="tel"
           name="telefono"
           placeholder="Teléfono">

    <input type="email"
           name="correo"
           placeholder="Correo">

    <input type="file"
           name="imagen">

   <select name="estado">
    <option value="Activo">Activo</option>
    <option value="Inactivo">Inactivo</option>
</select>

<button type="submit">
    Guardar
</button>

</form>
  @if(isset($clientes) && $clientes->count())

<table border="1">

    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Apellido</th>
        <th>Teléfono</th>
        <th>Correo</th>
        <th>Estado</th>
        <th>Imagen</th>
        <th>Fecha Registro</th>
        <th>Acciones</th>
    </tr>

    @foreach($clientes as $cliente)

    <tr>

        <td>{{ $cliente->id }}</td>
        <td>{{ $cliente->nombre }}</td>
        <td>{{ $cliente->apellido }}</td>
        <td>{{ $cliente->telefono }}</td>
        <td>{{ $cliente->correo }}</td>
        <td>{{ $cliente->estado }}</td>

        <td>
            @if($cliente->imagen)
                <img src="{{ asset('imagenes/'.$cliente->imagen) }}"
                     width="60">
            @endif
        </td>

        <td>{{ $cliente->fecha_registro }}</td>

        <td>
            
        </td>
        <td>

<a href="{{ route('clientes.mostrar',$cliente->id) }}"
class="bg-blue-500 px-2 py-1 rounded">

Mostrar

</a>

<a href="{{ route('clientes.editar',$cliente->id) }}"
class="bg-yellow-500 px-2 py-1 rounded">

Editar

</a>

<a href="{{ route('clientes.borrar',$cliente->id) }}"
class="bg-red-500 px-2 py-1 rounded">

Borrar

</a>

</td>

    </tr>

    @endforeach

</table>

@endif
    
</form>

@endsection

