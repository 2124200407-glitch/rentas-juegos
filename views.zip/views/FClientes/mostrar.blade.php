@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<h2 class="text-2xl mb-5">
    Mostrar Cliente
</h2>

<p><strong>ID:</strong> {{ $cliente->id }}</p>

<p><strong>Nombre:</strong>
{{ $cliente->nombre }}
</p>

<p><strong>Apellido:</strong>
{{ $cliente->apellido }}
</p>

<p><strong>Teléfono:</strong>
{{ $cliente->telefono }}
</p>

<p><strong>Correo:</strong>
{{ $cliente->correo }}
</p>

<p><strong>Estado:</strong>
{{ $cliente->estado }}
</p>

@if($cliente->imagen)

<img
src="{{ asset('imagenes/'.$cliente->imagen) }}"
width="150">

@endif

<br><br>

<a href="{{ route('clientes.formulario') }}"
class="bg-cyan-500 px-4 py-2 rounded">

Volver

</a>

</div>

@endsection