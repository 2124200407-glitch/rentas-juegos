@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<h2>Mostrar Categoría</h2>

<p>ID: {{ $categoria->id }}</p>

<p>Nombre: {{ $categoria->nombre }}</p>

<p>Estado: {{ $categoria->estado }}</p>

@if($categoria->imagen)

<img
src="{{ asset('imagenes/'.$categoria->imagen) }}"
width="150">

@endif

<br><br>

<a href="{{ route('categorias.formulario') }}">
Volver
</a>

</div>

@endsection