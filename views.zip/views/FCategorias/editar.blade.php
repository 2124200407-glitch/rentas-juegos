@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl shadow-lg">

    <h2 class="text-2xl font-bold text-cyan-400 mb-6 text-center">
        Editar Categoría
    </h2>

    <form method="POST"
          action="{{ route('categorias.actualizar',$categoria->id) }}"
          enctype="multipart/form-data">

        @csrf

        <input type="text"
               name="nombre"
               value="{{ $categoria->nombre }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white">

        <select name="estado"
                class="w-full p-3 rounded-lg bg-slate-700 text-white">

            <option value="Activo"
                {{ $categoria->estado == 'Activo' ? 'selected' : '' }}>
                Activo
            </option>

            <option value="Inactivo"
                {{ $categoria->estado == 'Inactivo' ? 'selected' : '' }}>
                Inactivo
            </option>

        </select>

        <button type="submit"
                class="w-full bg-yellow-500 py-3 rounded-lg font-bold mt-4">
            Actualizar
        </button>

    </form>

</div>

@endsection