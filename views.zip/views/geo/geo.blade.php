<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Geolocalización y Clima</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background:#f4f6f9;
            margin:0;
            padding:20px;
        }

        .contenedor{
            max-width:600px;
            margin:auto;
        }

        .panel{
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0px 2px 10px rgba(0,0,0,.2);
        }

        h2{
            text-align:center;
            color:#0d6efd;
        }

        .dato{
            font-size:18px;
            margin:10px 0;
        }

        .valor{
            font-weight:bold;
            color:#198754;
        }

        hr{
            margin:15px 0;
        }
    </style>
</head>
<body>

<div class="contenedor">

    <div class="panel">

        <h2>📍 Información Local</h2>

        <div class="dato">
            🏙 Ciudad:
            <span class="valor" id="ciudad">Cargando...</span>
        </div>

        <div class="dato">
            📌 Estado:
            <span class="valor" id="estado">Cargando...</span>
        </div>

        <div class="dato">
            🌎 País:
            <span class="valor" id="pais">Cargando...</span>
        </div>

        <hr>

        <div class="dato">
            🌡 Temperatura:
            <span class="valor" id="temperatura">Cargando...</span>
        </div>

        <div class="dato">
            💧 Humedad:
            <span class="valor" id="humedad">Cargando...</span>
        </div>

        <div class="dato">
            ☔ Probabilidad de lluvia:
            <span class="valor" id="lluvia">Cargando...</span>
        </div>

        <hr>

        <div class="dato">
            💵 Tipo de cambio:
            <span class="valor" id="tipoCambio">Cargando...</span>
        </div>

    </div>

</div>

<script>

// =============================
// UBICACIÓN POR IP
// =============================
fetch('https://ipapi.co/json/')
.then(response => response.json())
.then(data => {

    document.getElementById('ciudad').innerHTML =
        data.city || "No disponible";

    document.getElementById('estado').innerHTML =
        data.region || "No disponible";

    document.getElementById('pais').innerHTML =
        data.country_name || "No disponible";

    console.log("JSON Ubicación");
    console.log(data);

})
.catch(error => console.log(error));


// =============================
// CLIMA CON GEOLOCALIZACIÓN
// =============================
if (navigator.geolocation) {

    navigator.geolocation.getCurrentPosition(

        function(position){

            let lat = position.coords.latitude;
            let lon = position.coords.longitude;

            fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m&hourly=precipitation_probability`)

            .then(response => response.json())

            .then(data => {

                document.getElementById('temperatura').innerHTML =
                    data.current.temperature_2m + " °C";

                document.getElementById('humedad').innerHTML =
                    data.current.relative_humidity_2m + " %";

                document.getElementById('lluvia').innerHTML =
                    data.hourly.precipitation_probability[0] + " %";

                console.log("JSON Clima");
                console.log(data);

            });

        },

        function(error){

            console.log(error);

            document.getElementById('temperatura').innerHTML =
                "Permiso denegado";

            document.getElementById('humedad').innerHTML =
                "Permiso denegado";

            document.getElementById('lluvia').innerHTML =
                "Permiso denegado";

        }

    );

}


// =============================
// TIPO DE CAMBIO
// =============================
fetch('https://open.er-api.com/v6/latest/USD')

.then(response => response.json())

.then(data => {

    document.getElementById('tipoCambio').innerHTML =
        "1 USD = " + data.rates.MXN.toFixed(2) + " MXN";

    console.log("JSON Tipo de Cambio");
    console.log(data);

})

.catch(error => console.log(error));

</script>

</body>
</html>