@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl shadow-lg">

    <h2 class="text-2xl font-bold text-cyan-400 mb-6 text-center">
        Editar Consola
    </h2>

    <form method="POST"
          action="{{ route('consolas.actualizar',$consola->id) }}"
          enctype="multipart/form-data">

        @csrf

        <input type="text"
               name="nombre"
               value="{{ $consola->nombre }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-3">

        <input type="text"
               name="fabricante"
               value="{{ $consola->fabricante }}"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-3">

        <input type="file"
               name="imagen"
               class="w-full p-3 rounded-lg bg-slate-700 text-white mb-3">

        <select name="estado"
                class="w-full p-3 rounded-lg bg-slate-700 text-white mb-3">

            <option value="Activo"
                {{ $consola->estado == 'Activo' ? 'selected' : '' }}>
                Activo
            </option>

            <option value="Inactivo"
                {{ $consola->estado == 'Inactivo' ? 'selected' : '' }}>
                Inactivo
            </option>

        </select>

        @if($consola->imagen)

            <img src="{{ asset('imagenes/'.$consola->imagen) }}"
                 width="120"
                 class="mb-3">

        @endif

        <button type="submit"
                class="w-full bg-green-500 py-3 rounded-lg font-bold">

            Actualizar

        </button>

    </form>

</div>

@endsection