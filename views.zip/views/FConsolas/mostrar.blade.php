@extends('layouts.app')

@section('dinamico')

<div class="max-w-md mx-auto bg-slate-800 p-8 rounded-2xl">

<h2>Mostrar Consola</h2>

<p>ID: {{ $consola->id }}</p>

<p>Nombre: {{ $consola->nombre }}</p>

<p>Fabricante: {{ $consola->fabricante }}</p>

<p>Estado: {{ $consola->estado }}</p>

@if($consola->imagen)

<img
src="{{ asset('imagenes/'.$consola->imagen) }}"
width="150">

@endif

<br><br>

<a href="{{ route('consolas.formulario') }}">
Volver
</a>

</div>

@endsection