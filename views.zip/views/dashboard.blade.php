@extends('layouts.app')

@section('content')

<h1>

Bienvenido

{{ Auth::guard('admin')->user()->nombre }}

</h1>

<form method="POST"
      action="{{ route('logout') }}">

@csrf

<button>

Cerrar Sesión

</button>

</form>

@endsection