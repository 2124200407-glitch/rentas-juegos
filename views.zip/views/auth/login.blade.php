<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login Administrador</title>

<script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="bg-slate-900 flex justify-center items-center min-h-screen">

<div class="bg-slate-800 p-8 rounded-xl shadow-lg w-96">

    <h1 class="text-white text-3xl font-bold text-center mb-6">
        Login Administrador
    </h1>

    @if($errors->any())

    <div class="bg-red-500 text-white p-3 rounded mb-4">

        @foreach($errors->all() as $error)

            <p>{{ $error }}</p>

        @endforeach

    </div>

    @endif

    <form method="POST" action="/login">

        @csrf

        <input
            type="text"
            name="usuario"
            placeholder="Usuario"
            class="w-full p-3 rounded mb-4">

        <input
            type="password"
            name="contraseña"
            placeholder="Contraseña"
            class="w-full p-3 rounded mb-4">

        <button
            class="w-full bg-cyan-500 text-white p-3 rounded">

            Iniciar Sesión

        </button>

    </form>

</div>

</body>
</html>