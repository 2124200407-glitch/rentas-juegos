<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Videojuego extends Model
{
    protected $table = 'videojuegos';

    public $timestamps = false;

    protected $fillable = [
        'titulo',
        'genero',
        'precio_renta',
        'clasificacion',
        'stock',
        'consola_id',
        'imagen',
        'estado'
    ];
}