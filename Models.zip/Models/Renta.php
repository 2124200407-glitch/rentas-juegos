<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Renta extends Model
{
    protected $table = 'rentas';

    public $timestamps = false;

    protected $fillable = [
        'cliente_id',
        'videojuego_id',
        'fecha_renta',
        'fecha_devolucion',
        'estado',
        'imagen'
    ];
}