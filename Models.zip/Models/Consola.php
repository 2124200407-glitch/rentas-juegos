<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Consola extends Model
{
    protected $table = 'consolas';

    public $timestamps = false;

    protected $fillable = [
        'nombre',
        'fabricante',
        'imagen',
        'estado'
    ];
}