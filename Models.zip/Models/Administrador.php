<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Administrador extends Authenticatable
{
    use Notifiable;

    protected $table = 'administradores';

    protected $fillable = [
        'usuario',
        'contraseña',
        'nombre',
        'activo'
    ];

    public function getAuthPassword()
    {
        return $this->contraseña;
    }
}