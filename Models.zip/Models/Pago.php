<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Pago extends Model
{
        use HasFactory;
    protected $table = 'pagos';
    protected $casts = [
    'fecha_renta' => 'date',
    'fecha_devolucion' => 'date'
];

    public $timestamps = false;

    protected $fillable = [
        'renta_id',
        'monto',
        'metodo_pago',
        'fecha_pago'
    ];

    public function renta()
    {
        return $this->belongsTo(Renta::class);
    }
}