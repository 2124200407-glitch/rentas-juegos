<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Sucursal extends Model
{
        use HasFactory;
    protected $table = 'sucursales';

    public $timestamps = false;

    protected $fillable = [
        'nombre',
        'ciudad',
        'direccion'
    ];

    public function empleados()
    {
        return $this->hasMany(Empleado::class);
    }
}