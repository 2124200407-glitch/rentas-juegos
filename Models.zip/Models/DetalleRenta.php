<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class DetalleRenta extends Model
{
        use HasFactory;
    protected $table = 'detalles_rentas';

    public $timestamps = false;

    protected $fillable = [
        'renta_id',
        'videojuego_id',
        'cantidad'
    ];

    public function renta()
    {
        return $this->belongsTo(Renta::class);
    }

    public function videojuego()
    {
        return $this->belongsTo(Videojuego::class);
    }
}