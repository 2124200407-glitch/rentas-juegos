<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Empleado extends Model
{
    protected $table = 'empleados';

    public $timestamps = false;

    protected $fillable = [
        'nombre',
        'apellido',
        'puesto',
        'salario',
        'sucursal_id',
        'imagen',
        'estado'
    ];
}