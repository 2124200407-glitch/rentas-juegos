<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $credenciales = [

            'usuario' => $request->usuario,

            'password' => $request->contraseña,

            'activo' => 1

        ];

        if (
            Auth::guard('admin')
            ->attempt($credenciales)
        )
        {
            $request->session()->regenerate();

            return redirect('/dashboard');
        }

        return back()->withErrors([
            'error'=>'Credenciales incorrectas'
        ]);
    }

    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/login');
    }
}