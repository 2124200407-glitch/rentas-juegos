<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class EmpleadoController extends Controller
{
    public function formulario()
{
    $empleados = Empleado::all();

    return view('FEmpleados.inicio', compact('empleados'));
}
    public function guardar(Request $request)
    {
        // dd($request->all());

        $empleado = new Empleado();

        $empleado->nombre = $request->nombre;
        $empleado->apellido = $request->apellido;
        $empleado->puesto = $request->puesto;
        $empleado->salario = $request->salario;
        $empleado->sucursal_id = $request->sucursal_id;

        if ($request->hasFile('imagen')) {

            $archivo = $request->file('imagen');

            $nombreImagen = time().'_'.$archivo->getClientOriginalName();

            $archivo->move(public_path('imagenes'), $nombreImagen);

            $empleado->imagen = $nombreImagen;
        }

        $empleado->estado = $request->estado;

        $empleado->save();

        return redirect()->back();
    }

    public function editar($id)
{
    $empleado = Empleado::find($id);

    if(!$empleado){

        return redirect()
            ->route('empleados.formulario')
            ->with('error','ID no encontrado');
    }

    return view(
        'FEmpleados.editar',
        compact('empleado')
    );
}

public function actualizar(Request $request, $id)
{
    $empleado = Empleado::find($id);

    if(!$empleado){

        return redirect()
            ->route('empleados.formulario')
            ->with('error','ID no encontrado');
    }

    Validator::make($request->all(),[
        'nombre' => 'required|max:100',
        'apellido' => 'required|max:100',
        'puesto' => 'required|max:50'
    ])->validate();

    $empleado->nombre = $request->nombre;
    $empleado->apellido = $request->apellido;
    $empleado->puesto = $request->puesto;
    $empleado->salario = $request->salario;
    $empleado->sucursal_id = $request->sucursal_id;
    $empleado->estado = $request->estado;

    if($request->hasFile('imagen')){

        $archivo = $request->file('imagen');

        $nombreImagen =
            time().'_'.$archivo->getClientOriginalName();

        $archivo->move(
            public_path('imagenes'),
            $nombreImagen
        );

        $empleado->imagen = $nombreImagen;
    }

    $empleado->save();

    return redirect()
        ->route('empleados.formulario')
        ->with('success','Empleado actualizado');
}
}