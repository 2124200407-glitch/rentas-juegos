<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CategoriaController extends Controller
{
    public function editar($id)
    {
        $categoria = Categoria::find($id);

        if (!$categoria) {
            return redirect()
                ->route('categorias.formulario')
                ->with('error', 'ID no encontrado');
        }

        return view('FCategorias.editar', compact('categoria'));
    }

    public function actualizar(Request $request, $id)
    {
        $categoria = Categoria::find($id);

        if (!$categoria) {
            return redirect()
                ->route('categorias.formulario');
        }

        Validator::make($request->all(), [
            'nombre' => 'required|max:100'
        ])->validate();

        $categoria->nombre = $request->nombre;
        $categoria->estado = $request->estado;

        $categoria->save();

        return redirect()
            ->route('categorias.formulario');
    }

    public function formulario()
    {
        $categorias = Categoria::all();

        return view('FCategorias.inicio', compact('categorias'));
    }

    public function guardar(Request $request)
    {
        $categoria = new Categoria();

        $categoria->nombre = $request->nombre;
        $categoria->estado = $request->estado;

        if ($request->hasFile('imagen')) {

            $archivo = $request->file('imagen');

            $nombreImagen =
                time().'_'.$archivo->getClientOriginalName();

            $archivo->move(
                public_path('imagenes'),
                $nombreImagen
            );

            $categoria->imagen = $nombreImagen;
        }

        $categoria->save();

        return redirect()->back();
    }

    public function mostrar($id)
{
    $categoria = Categoria::find($id);

    if(!$categoria){

        return redirect()
            ->route('categorias.formulario');
    }

    return view(
        'FCategorias.mostrar',
        compact('categoria')
    );
}

public function borrar($id)
{
    $categoria = Categoria::find($id);

    if(!$categoria){

        return redirect()
            ->route('categorias.formulario');
    }

    $categoria->estado = 'Inactivo';

    $categoria->save();

    return redirect()
        ->route('categorias.formulario');
}
}