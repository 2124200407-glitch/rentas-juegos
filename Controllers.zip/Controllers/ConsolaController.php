<?php

namespace App\Http\Controllers;

use App\Models\Consola;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class ConsolaController extends Controller
{
    public function formulario()
    {
        $consolas = Consola::all();

        return view('FConsolas.inicio', compact('consolas'));
    }

    public function guardar(Request $request)
    {
        $consola = new Consola();

        $consola->nombre = $request->nombre;
        $consola->fabricante = $request->fabricante;
        $consola->estado = $request->estado;

        if ($request->hasFile('imagen')) {

            $archivo = $request->file('imagen');

            $nombreImagen = time().'_'.$archivo->getClientOriginalName();

            $archivo->move(public_path('imagenes'), $nombreImagen);

            $consola->imagen = $nombreImagen;
        }

        $consola->save();

        return redirect()->back();
    }

    public function editar($id)
{
    $consola = Consola::find($id);

    if (!$consola) {
        return redirect()
            ->route('consolas.formulario')
            ->with('error', 'ID no encontrado');
    }

    return view('FConsolas.editar', compact('consola'));
}

public function actualizar(Request $request, $id)
{
    $consola = Consola::find($id);

    if (!$consola) {
        return redirect()
            ->route('consolas.formulario')
            ->with('error', 'ID no encontrado');
    }

    Validator::make($request->all(), [
        'nombre' => 'required|max:100',
        'fabricante' => 'required|max:100'
    ])->validate();

    $consola->nombre = $request->nombre;
    $consola->fabricante = $request->fabricante;
    $consola->estado = $request->estado;

    if ($request->hasFile('imagen')) {

        $archivo = $request->file('imagen');

        $nombreImagen =
            time().'_'.$archivo->getClientOriginalName();

        $archivo->move(
            public_path('imagenes'),
            $nombreImagen
        );

        $consola->imagen = $nombreImagen;
    }

    $consola->save();

    return redirect()
        ->route('consolas.formulario')
        ->with('success', 'Consola actualizada');
}
public function mostrar($id)
{
    $consola = Consola::find($id);

    if(!$consola){

        return redirect()
            ->route('consolas.formulario');
    }

    return view(
        'FConsolas.mostrar',
        compact('consola')
    );
}

public function borrar($id)
{
    $consola = Consola::find($id);

    if(!$consola){

        return redirect()
            ->route('consolas.formulario');
    }

    $consola->estado = 'Inactivo';

    $consola->save();

    return redirect()
        ->route('consolas.formulario');
}
}