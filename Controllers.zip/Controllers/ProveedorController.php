<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class ProveedorController extends Controller
{
    public function editar($id)
{
    $proveedor = Proveedor::find($id);

    if (!$proveedor) {

        return redirect()
            ->route('proveedores.formulario')
            ->with('error','ID no encontrado');
    }

    return view(
        'FProveedores.editar',
        compact('proveedor')
    );
}

public function actualizar(Request $request, $id)
{
    $proveedor = Proveedor::find($id);

    if (!$proveedor) {

        return redirect()
            ->route('proveedores.formulario')
            ->with('error','ID no encontrado');
    }

    Validator::make(
        $request->all(),
        [
            'nombre' => 'required|max:100',
            'telefono' => 'required|max:20',
            'correo' => 'required|email'
        ]
    )->validate();

    $proveedor->nombre = $request->nombre;
    $proveedor->telefono = $request->telefono;
    $proveedor->correo = $request->correo;
    $proveedor->estado = $request->estado;

    if ($request->hasFile('imagen')) {

        $archivo = $request->file('imagen');

        $nombreImagen =
            time().'_'.$archivo->getClientOriginalName();

        $archivo->move(
            public_path('imagenes'),
            $nombreImagen
        );

        $proveedor->imagen = $nombreImagen;
    }

    $proveedor->save();

    return redirect()
        ->route('proveedores.formulario')
        ->with('success','Proveedor actualizado');
}
    public function formulario()
    {
        $proveedores = Proveedor::all();

        return view('FProveedores.inicio', compact('proveedores'));
    }

    public function guardar(Request $request)
    {
        $proveedor = new Proveedor();

        $proveedor->nombre = $request->nombre;
        $proveedor->telefono = $request->telefono;
        $proveedor->correo = $request->correo;
        $proveedor->estado = $request->estado;

        if ($request->hasFile('imagen')) {

            $archivo = $request->file('imagen');

            $nombreImagen = time().'_'.$archivo->getClientOriginalName();

            $archivo->move(public_path('imagenes'), $nombreImagen);

            $proveedor->imagen = $nombreImagen;
        }

        $proveedor->save();

        return redirect()->back();
    }
    public function mostrar($id)
{
    $proveedor = Proveedor::find($id);

    if(!$proveedor){

        return redirect()
            ->route('proveedores.formulario');
    }

    return view(
        'FProveedores.mostrar',
        compact('proveedor')
    );
}

public function borrar($id)
{
    $proveedor = Proveedor::find($id);

    if(!$proveedor){

        return redirect()
            ->route('proveedores.formulario');
    }

    $proveedor->estado = 'Inactivo';

    $proveedor->save();

    return redirect()
        ->route('proveedores.formulario');
}
}