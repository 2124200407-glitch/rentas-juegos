<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ClienteController extends Controller
{
    public function formulario()
    {
        $clientes = Cliente::all();

        return view('FClientes.inicio', compact('clientes'));
    }

    public function guardar(Request $request)
{
    $cliente = new Cliente();

    $cliente->nombre = $request->nombre;
    $cliente->apellido = $request->apellido;
    $cliente->telefono = $request->telefono;
    $cliente->correo = $request->correo;
    $cliente->estado = $request->estado;

    if ($request->hasFile('imagen')) {

        $archivo = $request->file('imagen');

        $nombreImagen =
            time().'_'.$archivo->getClientOriginalName();

        $archivo->move(
            public_path('imagenes'),
            $nombreImagen
        );

        $cliente->imagen = $nombreImagen;
    }

    $cliente->save();

    return redirect()->back();
}

    public function editar($id)
    {
        $cliente = Cliente::find($id);

        if (!$cliente) {
            return redirect()->route('clientes.formulario')
                ->with('error', 'El ID no existe');
        }

        return view('FClientes.editar', compact('cliente'));
    }

    public function actualizar(Request $request, $id)
    {
        $cliente = Cliente::find($id);

        if (!$cliente) {

            return redirect()
                ->route('clientes.formulario')
                ->with('error','El ID no existe');
        }

        $validator = Validator::make(
            $request->all(),
            [
                'nombre' => 'required|max:100',
                'apellido' => 'required|max:100',
                'correo' => 'required|email',
            ]
        );

        if ($validator->fails()) {

            return back()
                ->withErrors($validator)
                ->withInput();
        }

        $cliente->nombre = $request->nombre;
        $cliente->apellido = $request->apellido;
        $cliente->telefono = $request->telefono;
        $cliente->correo = $request->correo;
        $cliente->estado = $request->estado;

        $cliente->save();

        return redirect()
            ->route('clientes.formulario')
            ->with('success','Registro actualizado');
    }
}